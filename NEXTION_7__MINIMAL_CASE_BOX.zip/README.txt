                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2830604
NEXTION 7" MINIMAL CASE BOX by bgiovanny is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

CASE Box for Nextion 7" touch display, easy to install everywhere with two 4mm screws... 
I install that on top bar of Creality CR-10S.
The supports have an inclination of 60 and 45 degrees easy to see the display...

27/02/19 Add Nextion body and back v 2, I add Extended IO port and fix an issue from the old body...
Also add a new support nextion 60 degrees v 2, with 1mm more material on the top...

Ho realizzato questo case box per il nextion 7" semplice da stampare, non necessita supporti e altrettante semplice da assemblare.
Ho realizzato due supporti, uno a 60° e uno a 45° in modo da avere una visuale ottimale del display, in base a dove si vuole posizionare.
Ho realizzato la v 2 dove è stata aggiunta la porta Extended IO in modo da poterla sfruttare.

# Print Settings

Printer Brand: Creality
Printer: CR-10S
Rafts: No
Supports: No
Resolution: 0.2
Infill: 30%

Notes: 
CASE Box for Nextion 7" touch display, you just print and assembly all with 12 screws of diameter 13 x 2,45mm easy to cut the the excess part.
After assembly, you can install where you want, with two 4mm screws.
I add support 45*, now you can choose 60° or 45°...